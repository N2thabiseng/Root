
document.addEventListener("DOMContentLoaded", function () {

    // =====================================
    // 1. INTERACTIVE ACCORDION
    // =====================================
    document.querySelectorAll(".accordion").forEach(function (button) {
        button.addEventListener("click", function () {
            const panel = button.nextElementSibling;

            if (panel) {
                panel.classList.toggle("open");

                button.setAttribute(
                    "aria-expanded",
                    panel.classList.contains("open")
                );
            }
        });
    });


    // =====================================
    // 2. INTERACTIVE MAP - CONTACT PAGE
    // =====================================
    const mapElement = document.getElementById("map");

    if (mapElement) {
        if (typeof L !== "undefined") {
            const map = L.map(mapElement).setView(
                [-26.2041, 28.0473],
                12
            );

            L.tileLayer(
                "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                {
                    attribution: "&copy; OpenStreetMap contributors"
                }
            ).addTo(map);

            L.marker([-26.2041, 28.0473])
                .addTo(map)
                .bindPopup("Mel Wear")
                .openPopup();
        } else {
            console.error(
                "Map unavailable. Check that Leaflet is loaded."
            );
        }
    }


    // =====================================
    // 3. PRODUCT SEARCH - PRODUCTS PAGE
    // =====================================
    const searchInput = document.getElementById("productSearch");

    if (searchInput) {
        searchInput.addEventListener("input", function () {
            const searchText = searchInput.value.toLowerCase().trim();

            document.querySelectorAll(".product-item").forEach(
                function (product) {
                    const productName = product.textContent.toLowerCase();

                    product.style.display =
                        productName.includes(searchText) ? "" : "none";
                }
            );
        });
    }


    // =====================================
    // 4. GALLERY LIGHTBOX - GALLERY PAGE
    // =====================================
    const galleryImages = document.querySelectorAll(".gallery img");
    const lightbox = document.getElementById("lightbox");
    const lightboxImage = document.getElementById("lightboxImage");
    const closeLightbox = document.getElementById("closeLightbox");

    function closeGalleryLightbox() {
        if (lightbox) {
            lightbox.classList.remove("active");
        }
    }

    if (lightbox && lightboxImage) {

        galleryImages.forEach(function (img) {
            img.addEventListener("click", function () {
                lightboxImage.src = img.src;
                lightboxImage.alt = img.alt;
                lightbox.classList.add("active");
            });
        });

        if (closeLightbox) {
            closeLightbox.addEventListener("click", closeGalleryLightbox);
        }

        lightbox.addEventListener("click", function (event) {
            if (event.target === lightbox) {
                closeGalleryLightbox();
            }
        });

        // Close the lightbox using the Escape key
        document.addEventListener("keydown", function (event) {
            if (event.key === "Escape") {
                closeGalleryLightbox();
            }
        });
    }


    // =====================================
    // 5. HAMBURGER / PRODUCT DROPDOWN
    // =====================================
    const menuToggle = document.getElementById("menuToggle");
    const productDropdown = document.getElementById("ProductDropdown");

    if (menuToggle && productDropdown) {

        menuToggle.addEventListener("click", function () {
            const isOpen = productDropdown.classList.toggle("active");

            menuToggle.setAttribute("aria-expanded", isOpen);
            menuToggle.setAttribute(
                "aria-label",
                isOpen ? "Close products menu" : "Open products menu"
            );
        });

        // Close the dropdown when clicking outside
        document.addEventListener("click", function (event) {
            if (
                !productDropdown.contains(event.target) &&
                !menuToggle.contains(event.target)
            ) {
                productDropdown.classList.remove("active");
                menuToggle.setAttribute("aria-expanded", "false");
            }
        });
    }


    // =====================================
    // 6. FADE-IN ANIMATION
    // =====================================
    const animatedElements = document.querySelectorAll(".fade-in");

    if ("IntersectionObserver" in window) {

        const observer = new IntersectionObserver(
            function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        observer.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.1 }
        );

        animatedElements.forEach(function (element) {
            observer.observe(element);
        });

    } else {
        animatedElements.forEach(function (element) {
            element.classList.add("visible");
        });
    }

});

/* =====================================
   DYNAMIC PRODUCTS, SEARCH AND SORTING
===================================== */

const productList = document.getElementById("productList");
const productSearch = document.getElementById("productSearch");
const productSort = document.getElementById("productSort");
const productCount = document.getElementById("productCount");

// Sample Mel Wear products.
// Update these details to match your actual products.
const products = [
    {
        name: "Premium 3D Silicone T-Shirt",
        category: "T-shirts",
        price: 450
    },
    {
        name: "Luxury Hoodie",
        category: "Hoodies",
        price: 550
    },
    {
        name: "Premium Tracksuit",
        category: "Tracksuits",
        price: 750
    },
    {
        name: "Mel Wear Bucket Hat",
        category: "Caps",
        price: 250
    }
];

function displayProducts() {
    if (!productList) return;

    const searchText = productSearch
        ? productSearch.value.toLowerCase().trim()
        : "";

    const sortValue = productSort
        ? productSort.value
        : "default";

    let filteredProducts = products.filter(function (product) {
        return (
            product.name.toLowerCase().includes(searchText) ||
            product.category.toLowerCase().includes(searchText)
        );
    });

    if (sortValue === "price-low") {
        filteredProducts.sort((a, b) => a.price - b.price);
    } else if (sortValue === "price-high") {
        filteredProducts.sort((a, b) => b.price - a.price);
    } else if (sortValue === "name") {
        filteredProducts.sort((a, b) =>
            a.name.localeCompare(b.name)
        );
    }

    productList.replaceChildren();

    filteredProducts.forEach(function (product) {
        const card = document.createElement("article");
        card.className = "product-card";

        const heading = document.createElement("h3");
        heading.textContent = product.name;

        const category = document.createElement("p");
        category.textContent = product.category;

        const price = document.createElement("p");
        price.textContent = "R" + product.price.toFixed(2);

        card.append(heading, category, price);
        productList.appendChild(card);
    });

    if (productCount) {
        productCount.textContent =
            filteredProducts.length +
            (filteredProducts.length === 1
                ? " product found"
                : " products found");
    }

    if (filteredProducts.length === 0) {
        const message = document.createElement("p");
        message.textContent =
            "No products found. Try another search.";
        productList.appendChild(message);
    }
}

if (productList) {
    if (productSearch) {
        productSearch.addEventListener("input", displayProducts);
    }

    if (productSort) {
        productSort.addEventListener("change", displayProducts);
    }

    displayProducts();
}


const products = [
    {
        id: 1,
        name: "Premium 3D Silicone T-Shirt",
        category: "T-shirts",
        price: 450
    },
    {
        id: 2,
        name: "Luxury Hoodie",
        category: "Hoodies",
        price: 550
    },
    {
        id: 3,
        name: "Premium Tracksuit",
        category: "Tracksuits",
        price: 750
    },
    {
        id: 4,
        name: "Mel Wear Bucket Hat",
        category: "Caps",
        price: 250
    }
];

function displayProducts() {
    if (!productList) return;

    const searchText = productSearch
        ? productSearch.value.toLowerCase().trim()
        : "";

    const sortValue = productSort
        ? productSort.value
        : "default";

    let filteredProducts = products.filter(product =>
        product.name.toLowerCase().includes(searchText) ||
        product.category.toLowerCase().includes(searchText)
    );

    if (sortValue === "price-low") {
        filteredProducts.sort((a, b) => a.price - b.price);
    } else if (sortValue === "price-high") {
        filteredProducts.sort((a, b) => b.price - a.price);
    } else if (sortValue === "name") {
        filteredProducts.sort((a, b) =>
            a.name.localeCompare(b.name)
        );
    }

    productList.replaceChildren();

    filteredProducts.forEach(product => {
        const card = document.createElement("article");
        card.className = "product-card";

        const heading = document.createElement("h3");
        heading.textContent = product.name;

        const category = document.createElement("p");
        category.textContent = product.category;

        const price = document.createElement("p");
        price.textContent = "R" + product.price.toFixed(2);

        const button = document.createElement("button");
        button.className = "add-to-cart";
        button.textContent = "ADD TO CART";
        button.dataset.productId = product.id;

        card.append(heading, category, price, button);
        productList.appendChild(card);
    });

    if (productCount) {
        productCount.textContent =
            filteredProducts.length + " products found";
    }
}


// =====================================
// CART PAGE DISPLAY
// =====================================

const cartItemsContainer = document.getElementById("cartItems");
const cartTotalElement = document.getElementById("cartTotal");
const checkoutButton = document.getElementById("checkoutButton");

function displayCart() {

    if (!cartItemsContainer) return;

    const cart = getCart();

    cartItemsContainer.replaceChildren();

    let total = 0;

    cart.forEach(item => {

        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        const row = document.createElement("div");
        row.className = "cart-item";

        const name = document.createElement("h3");
        name.textContent = item.name;

        const price = document.createElement("p");
        price.textContent =
            "R" + item.price.toFixed(2);

        const quantity = document.createElement("input");
        quantity.type = "number";
        quantity.min = "1";
        quantity.max = "99";
        quantity.value = item.quantity;
        quantity.setAttribute(
            "aria-label",
            "Quantity for " + item.name
        );

        quantity.addEventListener("change", function() {

            const newQuantity = Math.max(
                1,
                Math.min(99, Number(this.value) || 1)
            );

            item.quantity = newQuantity;

            saveCart(cart);
            displayCart();
        });

        const removeButton = document.createElement("button");
        removeButton.textContent = "REMOVE";

        removeButton.addEventListener("click", function() {

            const updatedCart = getCart().filter(
                product => product.id !== item.id
            );

            saveCart(updatedCart);
            displayCart();
        });

        row.append(name, price, quantity, removeButton);

        cartItemsContainer.appendChild(row);

    });

    if (cart.length === 0) {
        cartItemsContainer.textContent =
            "Your shopping bag is currently empty.";
    }

    cartTotalElement.textContent =
        "Total: R" + total.toFixed(2);

    if (checkoutButton) {
        checkoutButton.disabled = cart.length === 0;
    }

    updateCartCount();
}

if (cartItemsContainer) {
    displayCart();
}

if (checkoutButton) {
    checkoutButton.addEventListener("click", function() {
        if (getCart().length > 0) {
            window.location.href = "checkout.html";
        }
    });
}

// MEL WEAR SHOPPING CART

document.addEventListener("click", function (event) {

    const button = event.target.closest(".add-to-cart");

    if (!button) return;

    const product = button.closest(".product-card");

    if (!product) {
        alert("Product information could not be found.");
        return;
    }

    const id = product.dataset.id;
    const name = product.querySelector("h3")?.textContent.trim();
    const price = Number(
        product.querySelector(".product-price")?.textContent
    );
    const image = product.querySelector("img")?.getAttribute("src");

    if (!id || !name || !Number.isFinite(price) || price <= 0) {
        alert("This product has incomplete information.");
        return;
    }

    let cart = JSON.parse(localStorage.getItem("melWearCart")) || [];

    const existingProduct = cart.find(item => item.id === id);

    if (existingProduct) {
        existingProduct.quantity += 1;
    } else {
        cart.push({
            id: id,
            name: name,
            price: price,
            image: image || "",
            quantity: 1
        });
    }

    localStorage.setItem("melWearCart", JSON.stringify(cart));

    updateCartCount();

    alert(name + " added to your cart!");
});


// UPDATE CART NUMBER

function updateCartCount() {

    const cart = JSON.parse(localStorage.getItem("melWearCart")) || [];

    const totalItems = cart.reduce(
        (total, item) => total + item.quantity, 0
    );

    const cartCount = document.getElementById("cart-count");

    if (cartCount) {
        cartCount.textContent = totalItems;
    }
}


// UPDATE CART WHEN PAGE LOADS

document.addEventListener("DOMContentLoaded", updateCartCount);
